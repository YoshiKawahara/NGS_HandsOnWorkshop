#!/bin/bash

WorkingDir=$HOME/RNA-Seq
ToolDir=$WorkingDir/tool
TrinotateImage=$ToolDir/trinotate.v4.0.2.simg

CPU=2

echo START: `date`

### Step 2: Run Trinotate for functional annotation
# create Trinotate DB

singularity exec -e $TrinotateImage \
  /usr/local/src/Trinotate/Trinotate \
  --create \
  --db myTrinotate.sqlite \
  --trinotate_data_dir TrinotateDB

# initialize Trinotate DB

export TRINOTATE_DATA_DIR=$WorkingDir/annot/TrinotateDB

ln -s ../denovo/trinity_out.Trinity.fasta.gene_trans_map Trinity.fasta.gene_trans_map

singularity exec -e $TrinotateImage \
  /usr/local/src/Trinotate/Trinotate \
  --db myTrinotate.sqlite \
  --init \
  --gene_trans_map Trinity.fasta.gene_trans_map \
  --transcript_fasta Trinity.fasta \
  --transdecoder_pep Trinity.fasta.transdecoder.pep

# make and store functional annotation

singularity exec -e $TrinotateImage \
  /usr/local/src/Trinotate/Trinotate \
  --db myTrinotate.sqlite \
  --CPU $CPU \
  --transcript_fasta Trinity.fasta \
  --transdecoder_pep Trinity.fasta.transdecoder.pep \
  --trinotate_data_dir TrinotateDB \
  --run "swissprot_blastp swissprot_blastx pfam tmhmmv2 EggnogMapper"

# output functional annotation

singularity exec -e $TrinotateImage \
  /usr/local/src/Trinotate/Trinotate \
  --db myTrinotate.sqlite \
  --report \
  > Trinotate_report.tsv

###

echo END: `date`



