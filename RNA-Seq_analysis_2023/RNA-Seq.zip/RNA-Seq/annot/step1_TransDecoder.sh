#!/bin/bash

WorkingDir=$HOME/RNA-Seq
ToolDir=$WorkingDir/tool
TransDecoderImage=$ToolDir/transdecoder.v5.7.1.simg

echo START: `date`

### Step 1: Extract the long open reading frames

ln -s ../denovo/trinity_out.Trinity.fasta Trinity.fasta

singularity exec -e $TransDecoderImage \
  TransDecoder.LongOrfs \
  -S \
  -t Trinity.fasta

### Predict the likely coding regions

singularity exec -e $TransDecoderImage \
  TransDecoder.Predict \
  -t Trinity.fasta \
  --single_best_only
###

echo END: `date`

