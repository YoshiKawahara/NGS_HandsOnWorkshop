#/bin/bash

WorkingDir=$HOME/RNA-Seq
DataDir=$WorkingDir/data
ToolDir=$WorkingDir/tool

StringTie_bin=$ToolDir/stringtie-2.2.1.Linux_x86_64

export PATH=$StringTie_bin:$PATH

CPU=2

echo START: `date`

### Step 4: Estimate transcript abundances

STRINGTIE_COMMON_PARAM="-e -B -p $CPU -G $DataDir/annotation.gtf"
OUTDIR=stringtie

for DATASET in rice_D_rep1 rice_D_rep2 rice_D_rep3 rice_N_rep1 rice_N_rep2 rice_N_rep3
do
  stringtie $STRINGTIE_COMMON_PARAM \
    -o ${OUTDIR}/${DATASET}/${DATASET}.gtf \
    -A ${OUTDIR}/${DATASET}/${DATASET}.abundance.txt \
    ${DATASET}.bam
done

###

echo END: `date`
