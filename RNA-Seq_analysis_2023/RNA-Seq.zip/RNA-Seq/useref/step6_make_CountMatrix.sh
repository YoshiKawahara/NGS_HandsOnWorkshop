#!/bin/bash

WorkingDir=$HOME/RNA-Seq
DataDir=$WorkingDir/data
ToolDir=$WorkingDir/tool

StringTie_bin=$ToolDir/stringtie-2.2.1.Linux_x86_64

export PATH=$StringTie_bin:$PATH

echo START: `date`

### Step 6: Make count matrix

python $StringTie_bin/prepDE.py3 \
  -l 101 \
  -i stringtie/ \
  -p rice_

###

echo END: `date`

