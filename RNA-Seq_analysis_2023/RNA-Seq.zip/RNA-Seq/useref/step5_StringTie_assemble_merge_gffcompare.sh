#/bin/bash

WorkingDir=$HOME/RNA-Seq
DataDir=$WorkingDir/data
ToolDir=$WorkingDir/tool

StringTie_bin=$ToolDir/stringtie-2.2.1.Linux_x86_64
gffcompare_bin=$ToolDir/gffcompare-0.12.6.Linux_x86_64
gffread_bin=$ToolDir/gffread-0.12.7.Linux_x86_64

export PATH=$StringTie_bin:$gffcompare_bin:$gffread_bin:$PATH

CPU=2

echo START: `date`

### Step 5-1: Assemble transcript structures by StringTie

STRINGTIE_COMMON_PARAM="-p $CPU"

for DATASET in rice_D_rep1 rice_D_rep2 rice_D_rep3 rice_N_rep1 rice_N_rep2 rice_N_rep3 
do
  stringtie $STRINGTIE_COMMON_PARAM \
    -o ${DATASET}.gtf \
    -l ${DATASET} \
    ${DATASET}.bam
done

### Step 5-2: Merge assembled transcript structures by StringTie
# make the list of assembled transcripts files

ls ./rice_*.gtf > assemblies.txt

# merge assembled transcripts
stringtie --merge \
  -G $DataDir/annotation.gtf \
  -o stringtie_merged.gtf \
  assemblies.txt

### Step 5-3: Compare assembled transcripts with the reference annotation
gffcompare \
  -r $DataDir/annotation.gtf \
  -o gffcmp \
  stringtie_merged.gtf

### Step 5-4: Make transcript sequence file
gffread \
  -g $DataDir/genome.fa \
  -w stringtie_merged_transcript.fa \
  stringtie_merged.gtf

###

echo END: `date`
