#!/bin/bash

echo START: `date`

mkdir tool
cd tool
ToolDir=`pwd`

##### for "useref" analysis
### install FastQC
echo "installing FastQC.."
wget --no-check-certificate https://www.bioinformatics.babraham.ac.uk/projects/fastqc/fastqc_v0.12.1.zip
unzip fastqc_v0.12.1.zip
chmod +x FastQC/fastqc

### install Trimmomatic
echo "installing Trimmomatic.."
wget http://www.usadellab.org/cms/uploads/supplementary/Trimmomatic/Trimmomatic-0.39.zip
unzip Trimmomatic-0.39.zip

### install HISAT2
echo "installing HISAT2.."
wget -O hisat2-2.2.1-Linux_x86_64.zip https://cloud.biohpc.swmed.edu/index.php/s/oTtGWbWjaxsQ2Ho/download
unzip hisat2-2.2.1-Linux_x86_64.zip

### install StringTie
echo "installing StringTie.."
wget http://ccb.jhu.edu/software/stringtie/dl/stringtie-2.2.1.Linux_x86_64.tar.gz
tar xfz stringtie-2.2.1.Linux_x86_64.tar.gz

### install Samtools
echo "installing Samtools.."
wget https://github.com/samtools/samtools/releases/download/1.18/samtools-1.18.tar.bz2
tar xfj samtools-1.18.tar.bz2
cd samtools-1.18
make
make prefix=`pwd` install
cd ..

### install gffcompare
echo "installing gffcompare.."
wget https://github.com/gpertea/gffcompare/releases/download/v0.12.6/gffcompare-0.12.6.Linux_x86_64.tar.gz
tar xfz gffcompare-0.12.6.Linux_x86_64.tar.gz

### install gffread
echo "installing gffread.."
wget https://github.com/gpertea/gffread/releases/download/v0.12.7/gffread-0.12.7.Linux_x86_64.tar.gz
tar xfz gffread-0.12.7.Linux_x86_64.tar.gz

##### for "denovo" analysis
### install Trinity
echo "installing Trinity.."
wget https://data.broadinstitute.org/Trinity/TRINITY_SINGULARITY/trinityrnaseq.v2.15.1.simg

# install Bowtie2
echo "installing Bowtie2..."
wget --no-check-certificate https://sourceforge.net/projects/bowtie-bio/files/bowtie2/2.5.1/bowtie2-2.5.1-linux-x86_64.zip
unzip bowtie2-2.5.1-linux-x86_64.zip

# install BLAST+
echo "installing BLAST+..."
wget https://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/LATEST/ncbi-blast-2.14.1+-x64-linux.tar.gz
tar xfz ncbi-blast-2.14.1+-x64-linux.tar.gz


##### for "annot" analysis
### install TransDecoder
echo "installing TransDecoder.."
wget https://data.broadinstitute.org/Trinity/CTAT_SINGULARITY/MISC/TransDecoder/transdecoder.v5.7.1.simg

### install Trinotate
echo "installing Trinotate.."
wget https://data.broadinstitute.org/Trinity/TRINOTATE_SINGULARITY/trinotate.v4.0.2.simg

echo END: `date`
