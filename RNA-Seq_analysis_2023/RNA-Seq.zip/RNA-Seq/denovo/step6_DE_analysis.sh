#!/bin/bash

WorkingDir=$HOME/RNA-Seq
ToolDir=$WorkingDir/tool
TrinityImage=$ToolDir/trinityrnaseq.v2.15.1.simg

echo START: `date`

### Step 6: Running differential expression analysis
singularity exec -e $TrinityImage \
  /usr/local/bin/Analysis/DifferentialExpression/run_DE_analysis.pl  \
  --matrix kallisto.gene.counts.matrix \
  --method DESeq2 \
  --samples_file sample_info.txt \
  --output DESeq2_out

# Extracting and clustering differentially expressed genes
cd DESeq2_out

singularity exec -e $TrinityImage \
  /usr/local/bin/Analysis/DifferentialExpression/analyze_diff_expr.pl \
  --matrix ../kallisto.gene.TMM.EXPR.matrix \
  -P 0.001 \
  -C 3 \
  --samples ../sample_info.txt

# Automatically partitioning genes into expression clusters
singularity exec -e $TrinityImage \
  /usr/local/bin/Analysis/DifferentialExpression/define_clusters_by_cutting_tree.pl \
  -R diffExpr.P0.001_C3.matrix.RData \
  --Ptree 60

###

echo END: `date`

