#!/bin/bash

WorkingDir=$HOME/RNA-Seq
ToolDir=$WorkingDir/tool
TrinityImage=$ToolDir/trinityrnaseq.v2.15.1.simg

echo START: `date`

### Step 4: Differential expression analysis
# compare replicates
singularity exec -e $TrinityImage \
  /usr/local/bin/Analysis/DifferentialExpression/PtR \
  --matrix kallisto.gene.counts.matrix \
  --samples sample_info.txt \
  --log2 \
  --CPM \
  --min_rowSums 30 \
  --compare_replicates

# Compare replicates across all samples
singularity exec -e $TrinityImage \
  /usr/local/bin/Analysis/DifferentialExpression/PtR \
  --matrix kallisto.gene.counts.matrix \
  --samples sample_info.txt \
  --log2 \
  --CPM \
  --min_rowSums 30 \
  --sample_cor_matrix

# PCA
singularity exec -e $TrinityImage \
  /usr/local/bin/Analysis/DifferentialExpression/PtR \
  --matrix kallisto.gene.counts.matrix \
  --samples sample_info.txt \
  --log2 \
  --CPM \
  --center_rows \
  --min_rowSums 30 \
  --prin_comp 3

###

echo END: `date`

