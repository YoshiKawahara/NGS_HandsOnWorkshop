#!/bin/bash

WorkingDir=$HOME/RNA-Seq
ToolDir=$WorkingDir/tool

TrinityImage=$ToolDir/trinityrnaseq.v2.15.1.simg

CPU=2
MEM=16G

echo START: `date`

### Step 2: De novo transcriptome assemble by Trinity

singularity exec -e $TrinityImage \
  Trinity \
  --seqType fq \
  --max_memory $MEM \
  --CPU $CPU \
  --samples_file `pwd`/sample_info.txt \
  --SS_lib_type RF \
  --output trinity_out

singularity exec -e $TrinityImage \
  /usr/local/bin/util/TrinityStats.pl \
  trinity_out.Trinity.fasta \
  > trinity_out.Trinity.fasta.stats

###

echo END: `date`

