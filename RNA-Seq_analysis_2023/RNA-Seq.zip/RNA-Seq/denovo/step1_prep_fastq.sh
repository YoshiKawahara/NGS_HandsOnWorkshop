#!/bin/bash

WorkingDir=$HOME/RNA-Seq
DataDir=$WorkingDir/data

echo START: `date`

### Step 1: Prepare input reads
# add suffix (/1 or /2) to original FASTQ header for Trinity

# for DATASET in rice_D_rep1 rice_D_rep2 rice_D_rep3 rice_N_rep1 rice_N_rep2 rice_N_rep3
# do
#   echo "converting ${DATASET}_r1 ..."
#   zcat $DataDir/${DATASET}_r1.org.fastq.gz \
#     | awk '{ if (NR%4==1) { print $1"/1" } else { print } }' \
#     | gzip -c > ${DATASET}_r1.trinity.fastq.gz
#
#   echo "converting ${DATASET}_r2 ..."
#   zcat $DataDir/${DATASET}_r2.org.fastq.gz \
#     | awk '{ if (NR%4==1) { print $1"/2" } else { print } }' \
#     | gzip -c > ${DATASET}_r2.trinity.fastq.gz
# done

###

for DATASET in rice_D_rep1 rice_D_rep2 rice_D_rep3 rice_N_rep1 rice_N_rep2 rice_N_rep3
do
  ln -s ${DataDir}/${DATASET}_r1.org.fastq.gz ./${DATASET}_r1.trinity.fastq.gz
  ln -s ${DataDir}/${DATASET}_r2.org.fastq.gz ./${DATASET}_r2.trinity.fastq.gz
done

###

echo END: `date`

