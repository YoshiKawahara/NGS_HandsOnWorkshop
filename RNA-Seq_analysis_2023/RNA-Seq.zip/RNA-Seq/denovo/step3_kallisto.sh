#!/bin/bash

WorkingDir=$HOME/RNA-Seq
ToolDir=$WorkingDir/tool

TrinityImage=$ToolDir/trinityrnaseq.v2.15.1.simg

CPU=2

echo START: `date`

### Step 3: Estimating transcript abundance

singularity exec -e $TrinityImage \
  /usr/local/bin/util/align_and_estimate_abundance.pl \
  --transcripts trinity_out.Trinity.fasta \
  --est_method kallisto \
  --seqType fq \
  --SS_lib_type RF \
  --samples_file sample_info.txt \
  --thread_count $CPU \
  --gene_trans_map trinity_out.Trinity.fasta.gene_trans_map \
  --prep_reference

# build transcript and gene expression matrices

ls */abundance.tsv > kallisto_abundance_tsv.list

singularity exec -e $TrinityImage \
  /usr/local/bin/util/abundance_estimates_to_matrix.pl \
  --est_method kallisto \
  --gene_trans_map trinity_out.Trinity.fasta.gene_trans_map \
  --name_sample_by_basedir \
  --quant_files kallisto_abundance_tsv.list
 
# counting numbers of expressed transcripts or genes

singularity exec -e $TrinityImage \
  /usr/local/bin/util/misc/count_matrix_features_given_MIN_TPM_threshold.pl \
  kallisto.isoform.TPM.not_cross_norm \
  > kallisto.isoform.TPM.not_cross_norm.counts_by_min_TPM

singularity exec -e $TrinityImage \
  /usr/local/bin/util/misc/count_matrix_features_given_MIN_TPM_threshold.pl \
  kallisto.gene.TPM.not_cross_norm \
  > kallisto.gene.TPM.not_cross_norm.counts_by_min_TPM

###

echo END: `date`

