#!/bin/bash

WorkingDir=$HOME/RNA-Seq
ToolDir=$WorkingDir/tool
Bowtie2_bin=$ToolDir/bowtie2-2.5.1-linux-x86_64
Samtools_bin=$ToolDir/samtools-1.18/bin
BLAST_bin=$ToolDir/ncbi-blast-2.14.1+/bin
TrinityImage=$ToolDir/trinityrnaseq.v2.15.1.simg

export PATH=$Bowtie2_bin:$Samtools_bin:$BLAST_bin:$PATH

CPU=2

echo START: `date`

### Step 5: Evalution of de novo transcriptome assemblies by Trinity
# check read representation

bowtie2-build \
  trinity_out.Trinity.fasta \
  trinity_out.Trinity.fasta

bowtie2 \
  -p $CPU \
  -q \
  --no-unal \
  -k 20 \
  -x trinity_out.Trinity.fasta \
  -1 rice_D_rep1_r1.trinity.fastq.gz,rice_D_rep2_r1.trinity.fastq.gz,rice_D_rep3_r1.trinity.fastq.gz,rice_N_rep1_r1.trinity.fastq.gz,rice_N_rep2_r1.trinity.fastq.gz,rice_N_rep3_r1.trinity.fastq.gz \
  -2 rice_D_rep1_r2.trinity.fastq.gz,rice_D_rep2_r2.trinity.fastq.gz,rice_D_rep3_r2.trinity.fastq.gz,rice_N_rep1_r2.trinity.fastq.gz,rice_N_rep2_r2.trinity.fastq.gz,rice_N_rep3_r2.trinity.fastq.gz \
  2> align_stats.txt \
  | samtools sort \
  -@ $CPU \
  -o bowtie2_read_to_contig.sort.bam

samtools index bowtie2_read_to_contig.sort.bam

samtools faidx trinity_out.Trinity.fasta

# homology search against rice protein sequences
ln -s ../data/rice_protein.fa

makeblastdb \
  -dbtype prot \
  -in rice_protein.fa

blastx \
  -query trinity_out.Trinity.fasta \
  -db rice_protein.fa \
  -task blastx-fast \
  -evalue 1e-20 \
  -max_target_seqs 1 \
  -outfmt 6 \
  -num_threads $CPU \
   -out blastx_trinity_to_rice_protein.outfmt6

singularity exec -e $TrinityImage \
  /usr/local/bin/util/misc/blast_outfmt6_group_segments.pl \
  blastx_trinity_to_rice_protein.outfmt6 \
  trinity_out.Trinity.fasta \
  rice_protein.fa \
  > blastx.outfmt6.grouped

singularity exec -e $TrinityImage \
  /usr/local/bin/util/misc/blast_outfmt6_group_segments.tophit_coverage.pl \
  blastx.outfmt6.grouped \
  > blastx_TopHitCoverage.grouped.txt

###

echo END: `date`
