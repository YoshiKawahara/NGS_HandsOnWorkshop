# install.packages("BiocManager")
# BiocManager::install("DESeq2")
# BiocManager::install("apeglm")
# install.packages("pheatmap")
# install.packages("RColorBrewer")
# install.packages("tidyverse")

library("DESeq2")
library("tidyverse")
library("pheatmap")
library("RColorBrewer")
library("apeglm")

### Load data & construct a DESeqDataSet(dds)

count_matrix <- as.matrix(read.csv("gene_count_matrix.csv", sep=",", row.names="gene_id"))

head(count_matrix)

sample_info <- data.frame(CONDITION=c("Day","Day","Day","Night","Night","Night"))
rownames(sample_info) <- c("rice_D_rep1","rice_D_rep2","rice_D_rep3",
                           "rice_N_rep1","rice_N_rep2","rice_N_rep3")
sample_info$CONDITION <- factor(sample_info$CONDITION, levels=c("Night","Day"))

sample_info

rownames(sample_info) %in% colnames(count_matrix)
all(rownames(sample_info) == colnames(count_matrix))

dds <- DESeqDataSetFromMatrix(countData = count_matrix,
                              colData = sample_info,
                              design = ~ CONDITION)

dds

### Pre-filtering
smallestGroupSize <- 3
keep <- rowSums(counts(dds) >= 10) >= smallestGroupSize
dds.filtered <- dds[keep,]

### Differential expression analysis
dds.filtered <- DESeq(dds.filtered)
res <- results(dds.filtered, contrast=c("CONDITION","Night","Day"))
head(res)
mcols(res)$description

### p-values and adjusted p-values
resOrdered <- res[order(res$pvalue),]
head(resOrdered)
summary(resOrdered)

res001 <- results(dds.filtered, contrast=c("CONDITION","Night","Day"), alpha=0.01)
summary(res001)

### Exporting results to TSV files
resSig <- subset(resOrdered, padj < 0.01)

write.table(as.data.frame(resSig), 
            file="DEG_genes.tsv", quote=F, sep="\t", row.names=T, col.names=NA)

### Plot TPM values in Boxplot
DTH2_TPM <- data.frame(CONDITION=c("Day","Day","Day","Night","Night","Night"),
                       TPM=c(513,468,417,18292,18494,18206))

ggplot(DTH2_TPM, aes(x=CONDITION, y=log2(TPM), fill=CONDITION)) +
  geom_boxplot() +
  geom_point() +
  scale_fill_manual(values=c("orange","blue")) +
  xlab("") +
  ylab("log2(TPM)")

### Extracting transformed values
vsd <- vst(dds, blind=FALSE)
head(assay(vsd))

### Heatmap of the sample-to-sample distances
sampleDists <- dist(t(assay(vsd)))
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(vsd$CONDITION, colnames(vsd), sep="-")
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
pheatmap(sampleDistMatrix,
         clustering_distance_rows=sampleDists,
         clustering_distance_cols=sampleDists,
         col=colors)

### PCA
plotPCA(vsd, intgroup=c("CONDITION"))

### MA-plot
resultsNames(dds.filtered)
resLFC <- lfcShrink(dds.filtered, coef="CONDITION_Day_vs_Night", type="apeglm")
plotMA(resLFC, ylim=c(-2,2), alpha=0.01)


